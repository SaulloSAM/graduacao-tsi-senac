﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Chacagem.Models
{
    public class CalcMedia
    {
        public double CalcularMedia (double prova1, double prova2)
        {
            double media = (prova1 + prova2) / 2;
            return media;
        }

        public double CalcularMedia(double prova1, double prova2, double prova3)
        {
            double media = (prova1 + prova2 + prova3) / 3;
            return media;
        }

        public string valiarSub(double resultMedia)
        {
            if (resultMedia >= 6)
                return "hidden";
            else
                return "";
        }

        public string msgClass (double resultMedia)
        {
            if (resultMedia >= 6)
                return "alert-success";
            else
                return "alert-danger";
        }
    }
}