﻿using Chacagem.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Chacagem.Controllers
{
    public class ChecagemController : Controller
    {
        // GET: Checagem
        public ActionResult Media()
        {
            ViewBag.form = "hidden";
            return View();
        }

        [HttpPost]
        public ActionResult Media(string prova1, string prova2)
        {
            CalcMedia media = new CalcMedia();
            double result = media.CalcularMedia(double.Parse(prova1), double.Parse(prova2));
            ViewBag.Resultado = result;
            ViewBag.fomr = media.valiarSub(result);
            ViewBag.Class = media.msgClass(result);
            return View();
        }
        
        public ActionResult Media3(string prova1, string prova2, string prova3)
        {
            CalcMedia media = new CalcMedia();
            double result = media.CalcularMedia(double.Parse(prova1), double.Parse(prova2), double.Parse(prova3));
            ViewBag.Resultado = result;
            ViewBag.fomr = media.valiarSub(result);
            ViewBag.Class = media.msgClass(result);
            return View("Media");
        }
    }      
}